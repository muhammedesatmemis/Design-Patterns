
package com.yusuf.edevlet.ceng431.factorypat;


public class Available implements Travel{

    private String situation;
    private String covid;
    private String age;
    private String vaccinated;

    public Available(String situation, String covid, String age, String vaccinated) {
        this.situation = situation;
        this.covid = covid;
        this.age = age;
        this.vaccinated = vaccinated;

    }

    @Override
    public String getSituation(){
        return situation;
    }

    @Override
    public String getCovid(){
        return covid;
    }

    @Override
    public String getAge(){
        return age;
    }

    @Override
    public String getVaccinated(){
        return vaccinated;
    }

    @Override
    public String toString(){
        return "Available(" +
                "situation='" + situation + '\'' +
                ", covid='" + covid + '\'' +
                ", age=" + age +
                ", vaccinated=" + vaccinated +
                '|';
    }

}
