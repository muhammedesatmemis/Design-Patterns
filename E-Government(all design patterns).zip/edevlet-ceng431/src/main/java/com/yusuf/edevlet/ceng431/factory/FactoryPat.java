
package com.yusuf.edevlet.ceng431.factorypat;


public class FactoryPat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

       Travel available = TravelFabrikasi.getTravel("available", " - ", " under 65 years old", " + ");
       Travel notAvailable = TravelFabrikasi.getTravel("notAvailable", " + ", " over 65 years old", " - ");

       System.out.println("Seyahat edebilir: ");
       System.out.println(available);

       System.out.println("----------------------------------");

       System.out.println("Seyahat edemez: ");
       System.out.println(notAvailable);


    }

}
