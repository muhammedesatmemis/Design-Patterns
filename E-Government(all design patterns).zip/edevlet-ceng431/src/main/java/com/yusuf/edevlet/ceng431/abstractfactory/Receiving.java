
package com.yusuf.edevlet.ceng431.abstractfactory;


public class Receiving implements Aid{

    private String salary;
    private String health_insurance;
    private String family_members;
    private String own_house;

    public Receiving(String salary, String batarya, String family_members, String own_house) {
        this.salary = salary;
        this.health_insurance = health_insurance;
        this.family_members = family_members;
        this.own_house = own_house;

    }

    @Override
    public String getSalary(){
        return salary;
    }

    @Override
    public String getHealth_Insurance(){
        return health_insurance;
    }

    @Override
    public String getFamily_Members(){
        return family_members;
    }

    @Override
    public String getOwn_House(){
        return own_house;
    }

    @Override
    public String toString(){
        return "Status Of Receiving Social Aid: (" +
                "salary= '" + salary + '\'' +
                ", health insurance= '" + health_insurance + '\'' +
                ", family members= " + family_members +
                ", own house= " + own_house +
                '|';
    }

}
