
package com.yusuf.edevlet.ceng431.factorypat;


public interface Travel {

    String getSituation();
    String getCovid();
    String getAge();
    String getVaccinated();


}
