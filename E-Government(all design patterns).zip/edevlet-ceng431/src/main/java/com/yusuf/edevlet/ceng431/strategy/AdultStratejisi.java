
package com.yusuf.edevlet.ceng431.strategy;


public class AdultStratejisi implements RandevuStratejisi {

    public EnumHospital getBirinci() {
        return EnumHospital.COUNTYHOSPITAL;
    }
        public EnumHospital getIkinci() {
        return EnumHospital.CITYHOSPITAL;
    }
        public EnumHospital getUcuncu() {
        return EnumHospital.RESEARCHHOSPITAL;
    }

        public EnumHospital getDorduncu() {
        return EnumHospital.HEALTHCLINIC;
    }

}