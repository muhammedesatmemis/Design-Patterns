
package com.yusuf.edevlet.ceng431.strategy;


public class YoungStratejisi implements RandevuStratejisi {

    public EnumHospital getBirinci() {
        return EnumHospital.HEALTHCLINIC;
    }
        public EnumHospital getIkinci() {
        return EnumHospital.COUNTYHOSPITAL;
    }
        public EnumHospital getUcuncu() {
        return EnumHospital.CITYHOSPITAL;
    }

        public EnumHospital getDorduncu() {
        return EnumHospital.RESEARCHHOSPITAL;
    }

}
