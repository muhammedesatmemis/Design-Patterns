package com.yusuf.edevlet.ceng431.adapter;

public class AstonMartin implements Movable {
    @Override
    public double getSpeed() {
        return 220;
    }
}