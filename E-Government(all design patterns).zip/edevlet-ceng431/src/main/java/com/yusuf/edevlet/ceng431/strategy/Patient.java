
package com.yusuf.edevlet.ceng431.strategy;


public class Patient {

    private EnumAge age;
    private RandevuStratejisi randevuStratejisi;

    public Patient (EnumAge age){
        this.age = age;

        if (age == null){
            throw new NullPointerException("Age boş olamaz");
        }

        switch (age){
            case YOUNG:
                randevuStratejisi = new YoungStratejisi();
                break;

            case OLD:
                randevuStratejisi = new OldStratejisi();
                break;

            case ADULT:
                randevuStratejisi = new AdultStratejisi();
                break;

            default:
                break;
        }
    }

    public String getOncelikSiralamasi(){

        System.out.println(age + " için strateji: ");

        String siralama = "Öncelikle " + randevuStratejisi.getBirinci() + " randevu alabilirsin. \n" +
                "2.olarak " + randevuStratejisi.getIkinci() + " randevu alabilirsin. \n" +
                "3.olarak " + randevuStratejisi.getUcuncu() + " randevu alabilirsin. \n" +
                "4.olarak " + randevuStratejisi.getDorduncu() + " randevu alabilirsin. \n";
        return siralama;
    }
}
