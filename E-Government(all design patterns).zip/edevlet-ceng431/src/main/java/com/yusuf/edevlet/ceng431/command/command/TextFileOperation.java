package com.yusuf.edevlet.ceng431.command.command;

@FunctionalInterface
public interface TextFileOperation {

    String execute();

}
