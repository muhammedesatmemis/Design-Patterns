
package com.yusuf.edevlet.ceng431.factorypat;


public class NotAvailable implements Travel{

    private String situation;
    private String covid;
    private String age;
    private String vaccinated;

    public NotAvailable(String situation, String covid, String age, String vaccinated) {
        this.situation = situation;
        this.covid = covid;
        this.age = age;
        this.vaccinated = vaccinated;

    }

    @Override
    public String getSituation(){
        return situation;
    }

    @Override
    public String getCovid(){
        return covid;
    }

    @Override
    public String getAge(){
        return age;
    }

    @Override
    public String getVaccinated(){
        return vaccinated;
    }

    @Override
    public String toString(){
        return "NotAvailable(" +
                "situation='" + situation + '\'' +
                ", covid='" + covid + '\'' +
                ", age=" + age +
                ", vaccinated=" + vaccinated +
                '|';
    }


}
