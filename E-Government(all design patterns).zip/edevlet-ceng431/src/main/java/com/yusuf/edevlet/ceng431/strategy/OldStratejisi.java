
package com.yusuf.edevlet.ceng431.strategy;


public class OldStratejisi implements RandevuStratejisi {

    public EnumHospital getBirinci() {
        return EnumHospital.RESEARCHHOSPITAL;
    }
        public EnumHospital getIkinci() {
        return EnumHospital.CITYHOSPITAL;
    }
        public EnumHospital getUcuncu() {
        return EnumHospital.COUNTYHOSPITAL;
    }

        public EnumHospital getDorduncu() {
        return EnumHospital.HEALTHCLINIC;
    }

}