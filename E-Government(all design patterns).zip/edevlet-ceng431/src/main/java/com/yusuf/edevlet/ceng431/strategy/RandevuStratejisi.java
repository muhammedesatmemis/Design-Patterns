
package com.yusuf.edevlet.ceng431.strategy;


public interface RandevuStratejisi {

    EnumHospital getBirinci();
    EnumHospital getIkinci();
    EnumHospital getUcuncu();
    EnumHospital getDorduncu();


}
