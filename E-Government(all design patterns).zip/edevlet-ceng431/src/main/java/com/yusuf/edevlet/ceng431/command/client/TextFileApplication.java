package com.yusuf.edevlet.ceng431.command.client;

import com.yusuf.edevlet.ceng431.command.command.OpenTextFileOperation;
import com.yusuf.edevlet.ceng431.command.command.SaveTextFileOperation;
import com.yusuf.edevlet.ceng431.command.command.TextFileOperation;
import com.yusuf.edevlet.ceng431.command.invoker.TextFileOperationExecutor;
import com.yusuf.edevlet.ceng431.command.receiver.TextFile;

public class TextFileApplication {

    public static void main(String[] args) {

        TextFileOperation openTextFileOperation = new OpenTextFileOperation(new TextFile("file1.txt"));
        TextFileOperation saveTextFileOperation = new SaveTextFileOperation(new TextFile("file2.txt"));
        
        TextFileOperationExecutor textFileOperationExecutor = new TextFileOperationExecutor();
        
        System.out.println(textFileOperationExecutor.executeOperation(openTextFileOperation));
        System.out.println(textFileOperationExecutor.executeOperation(saveTextFileOperation));
    }
}
