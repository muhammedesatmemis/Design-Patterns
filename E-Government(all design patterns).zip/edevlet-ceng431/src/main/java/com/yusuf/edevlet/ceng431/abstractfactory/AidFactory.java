
package com.yusuf.edevlet.ceng431.abstractfactory;


public interface AidFactory {

    Aid getAid(String salary, String health_insurance, String family_members, String own_house);

}
