package com.yusuf.edevlet.ceng431.decorator;

public interface ChristmasTree {
    String decorate();
}