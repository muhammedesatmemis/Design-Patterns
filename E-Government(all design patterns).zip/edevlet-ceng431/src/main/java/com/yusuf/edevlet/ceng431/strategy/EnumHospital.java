package com.yusuf.edevlet.ceng431.strategy;


public enum EnumHospital {


    HEALTHCLINIC("Health Clinic"),
    COUNTYHOSPITAL("County Hospital"),
    CITYHOSPITAL("City Hospital"),
    RESEARCHHOSPITAL("Research Hospital");

    private String hospital;

    EnumHospital(String hospital) {
        this.hospital = hospital;
    }

    @Override
    public String toString() {
        return hospital;
    }

}
