
package com.yusuf.edevlet.ceng431.abstractfactory;


public class ReceivingFabrikasi implements AidFactory{

    @Override
    public Aid getAid(String salary, String health_insurance, String family_members, String own_house) {

        return new Receiving(salary, health_insurance, family_members, own_house);
    }

}
