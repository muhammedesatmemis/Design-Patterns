package com.yusuf.edevlet.ceng431.adapter;

public class BugattiVeyron implements Movable {
    @Override
    public double getSpeed() {
        return 268;
    }
}