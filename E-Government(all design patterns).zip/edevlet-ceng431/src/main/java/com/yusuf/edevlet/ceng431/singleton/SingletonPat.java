
package singletonpat;


public class SingletonPat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        for (int i = 0;  i<5; i++){
            Singleton singleton = Singleton.getSingleton();
        }

    }

}
