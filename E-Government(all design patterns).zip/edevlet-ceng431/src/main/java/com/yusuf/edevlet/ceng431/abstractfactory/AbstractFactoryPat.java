
package com.yusuf.edevlet.ceng431.abstractfactory;


public class AbstractFactoryPat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

      ReceivingFabrikasi receivingFabrikasi = new ReceivingFabrikasi();
      Aid receiving = receivingFabrikasi.getAid("-2500 tl", "-", "+4", "-");


      NreceivingFabrikasi nreceivingFabrikasi = new NreceivingFabrikasi();
      Aid nreceiving = nreceivingFabrikasi.getAid("+2500 tl", "+", "-5", "+");

        System.out.println("Social Aid Verification\n");


        System.out.println(receiving);
        System.out.println(nreceiving);


}
}