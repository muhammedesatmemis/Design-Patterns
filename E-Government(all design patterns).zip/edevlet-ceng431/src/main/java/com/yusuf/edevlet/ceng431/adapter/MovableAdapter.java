package com.yusuf.edevlet.ceng431.adapter;

public interface MovableAdapter {
    // returns speed in KMPH
    double getSpeed();
}