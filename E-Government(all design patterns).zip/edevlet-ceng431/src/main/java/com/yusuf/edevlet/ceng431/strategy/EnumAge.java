
package com.yusuf.edevlet.ceng431.strategy;


public enum EnumAge {

    YOUNG("Young"),
    ADULT("Adult"),
    OLD("Old");


    private String age;

    EnumAge(String age) {
        this.age = age;
    }
    @Override
    public String toString() {
        return age;
    }
}
