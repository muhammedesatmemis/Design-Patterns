package com.yusuf.edevlet.ceng431.strategy;

public class StrategyPat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //System.out.println("-----------------");
        siralamaYazdir(EnumAge.YOUNG);
        System.out.println("-----------------");
        siralamaYazdir(EnumAge.ADULT);
        System.out.println("-----------------");
        siralamaYazdir(EnumAge.OLD);

    }
    private static void siralamaYazdir(EnumAge age){
        Patient patient = new Patient(age);
        String oncelikSiralamasi = patient.getOncelikSiralamasi();
        System.out.println(oncelikSiralamasi);
    }

}
