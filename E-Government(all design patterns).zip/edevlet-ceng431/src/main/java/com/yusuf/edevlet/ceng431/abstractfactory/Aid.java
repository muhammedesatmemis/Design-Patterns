
package com.yusuf.edevlet.ceng431.abstractfactory;


public interface Aid {

    String getSalary();
    String getHealth_Insurance();
    String getFamily_Members();
    String getOwn_House();


}
