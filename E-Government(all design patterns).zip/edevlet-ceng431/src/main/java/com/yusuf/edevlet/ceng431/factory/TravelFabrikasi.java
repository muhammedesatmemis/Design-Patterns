
package com.yusuf.edevlet.ceng431.factorypat;


public class TravelFabrikasi {

    public static Travel getTravel(String situation, String covid, String age, String vaccinated){
        Travel travel;
        if ("Available".equalsIgnoreCase(situation)){
            travel = new Available(situation, covid, age, vaccinated);
        }
        else if ("NotAvailable".equalsIgnoreCase(situation)){
            travel = new NotAvailable(situation, covid, age, vaccinated);
        }else{
            throw new RuntimeException("Geçerli bir model değildir!");
        }
        return travel;
    }

}
