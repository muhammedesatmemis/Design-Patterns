### Team

1. **Yusuf Emre Göksu** 14050111023
2. **Muhammed Esat Memi̇ş** 16050111013

### Pair Programming Project using Design Patterns

Video Link: https://www.youtube.com/watch?v=BFaNIIFT99g

**Video Content**

- App Design Discussions (How to design the app)
- Pattern Discussions (How can we use design patterns in the app)
- Hands-on Pair Programming 1 (Writing citizen class)
  **Yusuf** _Coding_
  **Muhammet** _Navigator_
- Hands-on Pair Programming 2 (Writing strategy pattern)
  **Muhammet** _Coding_
  **Yusuf** _Navigator_

<img src="./desc.png">

### Patterns That We've Used

**Observer Pattern** ✅

**Command Pattern** ✅

**Adapter Pattern** ✅

**Decorator Pattern** ✅

**Singleton Pattern** ✅

**Simple Factory Pattern** ✅

**Abstract Factory Pattern** ✅

**Strategy Pattern** ✅
Hospital Appointment Service
